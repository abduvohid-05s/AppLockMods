package com.applockmod

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private var inApps = false
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Store.hasPassword(this)) showEnter() else showSet()
    }

    private fun root(top: Int = 64): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(24), dp(top), dp(24), dp(24))
    }

    private fun title(t: String) = TextView(this).apply {
        text = t; textSize = 22f; setPadding(0, 0, 0, dp(16))
    }

    private fun pwField(h: String) = EditText(this).apply {
        hint = h
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
    }


    private fun serviceOn(): Boolean {
        val v = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return v.contains("$packageName/")
    }

    private fun setupButtons(l: LinearLayout) {
        if (!serviceOn()) {
            l.addView(Button(this).apply {
                text = "1. Qulf xizmatini yoqish (Maxsus imkoniyatlar)"
                setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            })
        }
        if (!Settings.canDrawOverlays(this)) {
            l.addView(Button(this).apply {
                text = "2. Boshqa ilovalar ustida ko'rsatishga ruxsat"
                setOnClickListener {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                }
            })
        }
    }

    override fun onResume() {
        super.onResume()
        if (inApps) showApps()
    }

    private fun showSet() {
        inApps = false
        val l = root()
        l.addView(title("Yangi parol o'ylab toping"))
        val p1 = pwField("Parol")
        val p2 = pwField("Parolni takrorlang")
        val btn = Button(this).apply { text = "Saqlash" }
        btn.setOnClickListener {
            val a = p1.text.toString()
            when {
                a.length < 4 -> toast("Kamida 4 ta belgi kiriting")
                a != p2.text.toString() -> toast("Parollar mos emas")
                else -> { Store.setPassword(this, a); showApps() }
            }
        }
        l.addView(p1); l.addView(p2); l.addView(btn)
        setContentView(l)
    }

    private fun showEnter() {
        inApps = false
        val l = root()
        l.addView(title("Parolni kiriting"))
        val p = pwField("Parol")
        val btn = Button(this).apply { text = "Kirish" }
        btn.setOnClickListener {
            if (Store.check(this, p.text.toString())) showApps() else toast("Parol noto'g'ri")
        }
        l.addView(p); l.addView(btn)
        setContentView(l)
    }

    private fun showApps() {
        inApps = true
        val pm = packageManager
        val locked = Store.locked(this).toMutableSet()
        val launch = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launch, 0)
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }

        val l = root(32)
        l.addView(title("Qulflanadigan ilovalarni belgilang"))
        setupButtons(l)
        for (ri in apps) {
            val pkg = ri.activityInfo.packageName
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(4), 0, dp(4))
            }
            row.addView(ImageView(this).apply { setImageDrawable(ri.loadIcon(pm)) },
                LinearLayout.LayoutParams(dp(40), dp(40)))
            val cb = CheckBox(this).apply {
                text = ri.loadLabel(pm).toString()
                isChecked = pkg in locked
                setPadding(dp(12), 0, 0, 0)
                setOnCheckedChangeListener { _, on ->
                    if (on) locked.add(pkg) else locked.remove(pkg)
                    Store.setLocked(this@MainActivity, locked)
                }
            }
            row.addView(cb, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            l.addView(row)
        }
        setContentView(ScrollView(this).apply { addView(l) })
    }
}
