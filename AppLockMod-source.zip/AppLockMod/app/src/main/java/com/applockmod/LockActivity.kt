package com.applockmod

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView

class LockActivity : Activity() {
    companion object { const val EXTRA_PKG = "pkg" }

    private var web: WebView? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        // skrinshot va "oxirgi ilovalar" da ko'rinmasin
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE)
        build()
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        setIntent(i)
        build()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun build() {
        val pkg = intent.getStringExtra(EXTRA_PKG) ?: run { finish(); return }
        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) { pkg }

        web?.destroy()
        val w = WebView(this)
        w.setBackgroundColor(Color.BLACK)
        w.settings.javaScriptEnabled = true
        w.settings.allowFileAccess = false      // faqat file:///android_asset ishlaydi
        w.settings.allowContentAccess = false
        w.settings.mediaPlaybackRequiresUserGesture = false
        w.addJavascriptInterface(Bridge(pkg, label), "Android")
        w.loadUrl("file:///android_asset/lock.html")
        web = w
        setContentView(w)
    }

    inner class Bridge(private val pkg: String, private val label: String) {
        @JavascriptInterface fun label(): String = label

        @JavascriptInterface fun submit(pw: String): Boolean {
            val ok = Store.check(this@LockActivity, pw)
            if (ok) runOnUiThread {
                LockService.unlocked = pkg
                finish()
            }
            return ok
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }

    override fun onDestroy() {
        web?.destroy()
        super.onDestroy()
    }
}
