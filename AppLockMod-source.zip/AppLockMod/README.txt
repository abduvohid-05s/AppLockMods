AppLock (oddiy APK, root/Magisk kerak emas)
- Qulflangan ilova ochilganda app/src/main/assets/lock.html (Matrix oynasi) chiqadi.
- Ovoz: sound.m4a ni app/src/main/assets/ ga qo'ying.
- Yig'ish: GitHub'ga yuklang -> Actions -> AppLock-apk artifact -> app-debug.apk
- O'rnatgach: ilovani oching, parol o'ylab toping, 2 ta ruxsatni bering.
